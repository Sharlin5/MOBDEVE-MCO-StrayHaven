package com.mobdeve.s11.manuel.tang.strayhaven;

public enum Collections {
    users,
    feeds
}
