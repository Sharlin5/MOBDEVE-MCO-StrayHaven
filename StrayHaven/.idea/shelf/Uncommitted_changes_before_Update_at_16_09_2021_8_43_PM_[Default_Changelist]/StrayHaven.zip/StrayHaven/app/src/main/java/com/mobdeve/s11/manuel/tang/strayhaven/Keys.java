package com.mobdeve.s11.manuel.tang.strayhaven;

public enum Keys {
    KEY_USERNAME,
    KEY_FEED_CAPTION,
    KEY_FEED_USERNAME,
    KEY_FEED_LOCATION,
    KEY_FEED_TYPE,
    KEY_FEED_IMAGE,
    KEY_MESSAGE_USERNAME,
    KEY_MESSAGE_IMAGE
}
